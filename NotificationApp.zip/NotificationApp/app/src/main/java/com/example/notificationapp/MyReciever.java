package com.example.notificationapp;

import static android.content.Context.NOTIFICATION_SERVICE;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.util.Log;
import androidx.core.content.res.ResourcesCompat;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;

public class MyReciever extends BroadcastReceiver {

    private static final  int NOTIFICATION_ID=100;
    private static final String TAG="MyTag";
    private static final String CHANNEL_ID="STANDARD";
    @Override
    public void onReceive(Context context, Intent intent) {

        Drawable drawable= ResourcesCompat.getDrawable(context.getResources(),R.drawable.icon_alarm,null);
        BitmapDrawable bitmapDrawable= (BitmapDrawable) drawable;
        Bitmap largeIcon=  bitmapDrawable.getBitmap();
        NotificationManager nm= (NotificationManager) context.getSystemService(NOTIFICATION_SERVICE);

        Notification notification= null;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            NotificationChannel nc=new NotificationChannel(CHANNEL_ID,CHANNEL_ID,NotificationManager.IMPORTANCE_HIGH);
            nm.createNotificationChannel(nc);

            notification = new Notification.Builder(context)
                    .setLargeIcon(largeIcon)
                    .setSmallIcon(R.drawable.icon_alarm)
                    .setContentText("Reminder Notification")
                    .setSubText("Hello There")
                    .setChannelId(CHANNEL_ID)
                    .build();
        }
        else
        {
            notification = new Notification.Builder(context)
                    .setLargeIcon(largeIcon)
                    .setSmallIcon(R.drawable.icon_alarm)
                    .setContentText("Reminder Notification")
                    .setSubText("Hello There")
                    .build();
        }

        Log.e(TAG, "onCreate: ");

        nm.notify(NOTIFICATION_ID,notification);


    }



}
