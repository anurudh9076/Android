package com.example.notificationapp;

import static android.content.ContentValues.TAG;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.res.ResourcesCompat;

import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TimePicker;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class MainActivity extends AppCompatActivity {

    private static final  int NOTIFICATION_ID=101;
     static final int ALARM_REQ_CODE=100;
    private static final String TAG="MyTag";
    private static final String CHANNEL_ID="STANDARD";
    Button btnDatePicker, btnTimePicker;
    EditText txtDate, txtTime;
    private int mYear, mMonth, mDay, mHour, mMinute;
    private int lYear,lMonth,lDay,lHour,lMinute;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        AlarmManager alarmManager =(AlarmManager) getSystemService(ALARM_SERVICE);

        btnDatePicker=(Button)findViewById(R.id.btn_date);
        btnTimePicker=(Button)findViewById(R.id.btn_time);
        txtDate=(EditText)findViewById(R.id.in_date);
        txtTime=(EditText)findViewById(R.id.in_time);

        btnDatePicker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Get Current Date
                final Calendar c = Calendar.getInstance();
                mYear = c.get(Calendar.YEAR);
                mMonth = c.get(Calendar.MONTH);
                mDay = c.get(Calendar.DAY_OF_MONTH);


                DatePickerDialog datePickerDialog = new DatePickerDialog(MainActivity.this,
                        new DatePickerDialog.OnDateSetListener() {

                            @Override
                            public void onDateSet(DatePicker view, int year,
                                                  int monthOfYear, int dayOfMonth) {

                                txtDate.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);
                                lDay=dayOfMonth;
                                lYear=year;
                                lMonth=monthOfYear;
                            }
                        }, mYear, mMonth, mDay);
                datePickerDialog.show();
            }
        });
        btnTimePicker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                // Get Current Time
                final Calendar c = Calendar.getInstance();
                mHour = c.get(Calendar.HOUR_OF_DAY);
                mMinute = c.get(Calendar.MINUTE);

                // Launch Time Picker Dialog
                TimePickerDialog timePickerDialog = new TimePickerDialog(MainActivity.this,
                        new TimePickerDialog.OnTimeSetListener() {

                            @Override
                            public void onTimeSet(TimePicker view, int hourOfDay,
                                                  int minute) {

                                txtTime.setText(hourOfDay + ":" + minute);
                                lMinute=minute;
                                lHour=hourOfDay;

                            }
                        }, mHour, mMinute, true);
                timePickerDialog.show();
            }
        });


        findViewById(R.id.btnNot).setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View view) {

                Calendar myAlarmDate = Calendar.getInstance();
                myAlarmDate.setTimeInMillis(System.currentTimeMillis());
                myAlarmDate.set(Calendar.MILLISECOND, 0);

                myAlarmDate.set(lYear, lMonth, lDay, lHour, lMinute, 0);


                Log.i("timeofnot", ""+lYear+"-"+lMonth+"-"+lDay+": "+lHour+":"+lMinute);
                Log.i(TAG,"current:"+(System.currentTimeMillis()));


                    //int time= Integer.parseInt(((EditText)findViewById(R.id.edtTime)).getText().toString());
                    //long triggerTime =System.currentTimeMillis()+(time*1000);
                //Log.i(TAG, "plus30 "+triggerTime);
                    Intent iBroadcast=new Intent(MainActivity.this,MyReciever.class);
                    PendingIntent pi= PendingIntent.getBroadcast(MainActivity.this,ALARM_REQ_CODE,iBroadcast,PendingIntent.FLAG_MUTABLE);
                    alarmManager.setExact(AlarmManager.RTC_WAKEUP,myAlarmDate.getTimeInMillis(),pi);
                Toast.makeText(MainActivity.this, "Notification Set", Toast.LENGTH_SHORT).show();
                    Log.i(TAG, "Difference: "+(myAlarmDate.getTimeInMillis()-System.currentTimeMillis()));




            }
        });





    }



}